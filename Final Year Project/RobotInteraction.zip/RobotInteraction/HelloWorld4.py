from naoqi import qi
tts = session.service("ALTextToSpeech")
tts.say("Hello, world!")
